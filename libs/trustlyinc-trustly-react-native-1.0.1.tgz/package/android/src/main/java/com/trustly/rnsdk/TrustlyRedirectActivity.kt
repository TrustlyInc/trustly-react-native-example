package com.trustly.rnsdk

import android.net.Uri
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import java.io.Serializable

/**
 * Intercepts the deep-link redirect that Chrome fires once the Trustly auth flow
 * completes. Mirrors TrustlyRedirectActivity from the Trustly Android SDK.
 *
 * This activity is registered in the library manifest with an intent-filter for
 * the app's URL scheme (trustly_url_scheme). When Chrome redirects to:
 *
 *   trustly-url-scheme://return/?trustlyContext=...&status=...
 *   trustly-url-scheme://cancel/?trustlyContext=...
 *
 * Android routes the intent here. This activity:
 *   1. Reads the full deep-link URL from intent.data.
 *   2. Starts TrustlyCustomTabsActivity with FLAG_ACTIVITY_CLEAR_TOP so that
 *      the Chrome Custom Tabs activity sitting on top of it is dismissed and
 *      TrustlyCustomTabsActivity.onNewIntent receives the return URL.
 *   3. Finishes itself immediately.
 *
 * Because TrustlyCustomTabsActivity uses launchMode=singleTop, FLAG_ACTIVITY_CLEAR_TOP
 * + FLAG_ACTIVITY_SINGLE_TOP ensures onNewIntent (not onCreate) is called on the
 * existing instance, preserving the pending Promise reference.
 */
class TrustlyRedirectActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (intent.data != null && intent.data!!.getQueryParameter(STATUS_PARAM) != null) {
            val intent = Intent(this, TrustlyCustomTabsActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(
                    TrustlyCustomTabsActivity.EXTRA_RETURN_URL,
                    intent.data?.toString()
                )
            startActivity(intent)
        } else {
            Handler(Looper.getMainLooper()).postDelayed({
                finish()
            }, 1500)
        }
    }

    companion object {

        private const val STATUS_PARAM = "status"

    }
}
