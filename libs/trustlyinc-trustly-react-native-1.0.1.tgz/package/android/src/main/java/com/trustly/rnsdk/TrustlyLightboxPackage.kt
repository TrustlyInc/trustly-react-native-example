package com.trustly.rnsdk

import com.facebook.react.ReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.uimanager.ViewManager

/**
 * ReactPackage that registers the TrustlyLightboxModule.
 *
 * Consuming apps must add this package to their MainApplication:
 *
 *   // MainApplication.kt
 *   override fun getPackages(): List<ReactPackage> =
 *       PackageList(this).packages + listOf(TrustlyLightboxPackage())
 *
 *   // MainApplication.java
 *   @Override
 *   protected List<ReactPackage> getPackages() {
 *       List<ReactPackage> packages = new PackageList(this).getPackages();
 *       packages.add(new TrustlyLightboxPackage());
 *       return packages;
 *   }
 */
class TrustlyLightboxPackage : ReactPackage {

    override fun createNativeModules(reactContext: ReactApplicationContext): List<NativeModule> =
        listOf(TrustlyLightboxModule(reactContext))

    override fun createViewManagers(reactContext: ReactApplicationContext): List<ViewManager<*, *>> =
        emptyList()
}
