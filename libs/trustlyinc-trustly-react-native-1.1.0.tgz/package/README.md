# Trustly React Native SDK

The official Trustly React Native SDK for integrating Trustly payment solutions into your React Native applications.

## Requirements

- **Node** 20
- **React** 18.3.1 or higher
- **React Native** 0.76.9 or higher

## Installation in Your React Native App

### Step 1: Install the SDK

Install the package from NPM:

```shell
npm install @trustlyinc/trustly-react-native
```

Or using yarn:

```shell
yarn add @trustlyinc/trustly-react-native
```

### Step 2: Install Peer Dependencies

The SDK requires the following peer dependencies to be installed in your project:

```shell
npm install react react-native react-native-inappbrowser-reborn react-native-webview @react-native-async-storage/async-storage react-native-get-random-values --legacy-peer-deps
```

Or using yarn:

```shell
yarn add react react-native react-native-inappbrowser-reborn react-native-webview @react-native-async-storage/async-storage react-native-get-random-values
```

### Step 3: Integration

To get up and running with this SDK, check out the [example application](https://github.com/TrustlyInc/trustly-react-native-example/).

## Development

### Setup

We recommend [**Visual Studio Code**](https://code.visualstudio.com/) as the code editor. There are some [settings](.vscode/settings.json) for it versioned in this repository. Please also install its recommended [extensions](.vscode/extensions.json).

### Install Dependencies

```shell
npm install
```

### Build the SDK

Build the TypeScript source code to JavaScript:

```shell
npm run build
```

The compiled output will be in the `dist/` directory.

### Local Development with Example App

To test the SDK locally with the example application:

```shell
npm run local
```

This command will:
1. Clean the example app's node_modules
2. Build the SDK
3. Pack it as a tarball
4. Install the packed SDK into the example app
